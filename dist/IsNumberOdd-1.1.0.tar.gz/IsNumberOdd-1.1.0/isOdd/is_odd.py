from isEven.is_even import is_even

def is_odd(numero):
    return not is_even (numero)
